# Sistema de Chat en Línea en PHP y MySQL
<img src="https://i0.wp.com/www.configuroweb.com/wp-content/uploads/2022/05/Sistema-de-Chat-en-Linea-en-PHP-y-MySQL.png?resize=800%2C500&ssl=1">
Este Sistema de Chat en Línea en PHP y MySQL con Código Fuente le permite al usuario registrarse y comunicarse con los usuarios que están conectados, la gran diferencia entre los chats anteriores es que este cambia en tiempo real, gracias a la tecnología de Ajax, solo recarga el div donde se encuentra el chat especifico y esto que la conversación por el chat sea más fluida.

Más información en el siguiente enlace: <a href="https://www.configuroweb.com/sistema-de-chat-en-linea-en-php-y-mysql/">Sistema de Chat en Línea en PHP y MySQL</a>
